/* File pcinddef.h */

#ifndef PCINDDEF_HEADER
#define PCINDDEF_HEADER

typedef int PCIND_T;

#endif
