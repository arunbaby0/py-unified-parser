/***/
#ifndef WCHARDEF_HEADER
#define WCHARDEF_HEADER

typedef int WCHAR_T;

#endif
