/* file ssstr1.h */

#ifndef SSSTR1_HEADER
#define SSSTR1_HEADER

  struct substring
    {char *start;
     char *end;
    };
  typedef struct substring SUBSTRING;

#endif
