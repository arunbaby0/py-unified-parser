/* file gdatadec.h */
/* global definitions (NOT declarations that reserve space) */
#ifndef GDATADEC_HEADER
#define GDATADEC_HEADER

extern int db_level;
extern int detail_level;
extern char db[272], *pdb;
extern boolean memory_trace;
extern char null_char_string[1], *EMPTY_STRING, *NIL_STRING;
extern int nstr_empty[1], *EMPTY_INT_STRING;

#endif
