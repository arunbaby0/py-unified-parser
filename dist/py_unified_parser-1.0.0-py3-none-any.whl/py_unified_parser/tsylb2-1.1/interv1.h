/* file interv1.h */
#ifndef INTERVAL1_HEADER
#define INTERVAL1_HEADER

 struct INTERVAL1 {int l1,l2;};

#endif
