/* file num_rel.h */
/* a numeric relation, such as " > 6 " */
#ifndef NUM_REL_HEADER
#define NUM_REL_HEADER

 typedef struct
  {char relation;
   int value;
  } NUM_REL;


#endif
