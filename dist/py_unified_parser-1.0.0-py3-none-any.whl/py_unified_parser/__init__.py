from .version import __version__
from .Word import Word

__all__ = [
    "Word",
    "__version__",
]
