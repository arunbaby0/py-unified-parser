# Supported languages

# For Enabling or disabling languages, Change the flag to True or False

LANGUAGES = {
    "Malayalam": True,
    "Tamil": True,
    "Telugu": True,
    "Kannada": True,
    "Hindi": True,
    "Bengali": True,
    "Gujarati": True,
    "Odia": False,
    "English": True,
    "Latin": True,
}
